import { LoginDetails } from "../login/login.component";
import { Todo } from "../main/main.component";

export let todos: Todo[] = [];
export let users: LoginDetails[] = [
    { username: 'user1', password: 'user1' },
    { username: 'Sid', password: 'Pass@123' }
];