import { Output } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {

  @Output()
  newtodo:EventEmitter<Todo> = new EventEmitter<Todo>();

  @Output()
  itemleft:EventEmitter<Todo> = new EventEmitter<Todo>();

  constructor() { }

  ngOnInit(): void {
  }

  addTodo(todoform:NgForm)
  {
    console.log(todoform);
    this.newtodo.emit(todoform.value);
    todoform.reset();
    // itemleft=itemleft+1;
  }
}

export interface Todo {
  todo:string;
  isChecked:boolean;
}
