import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private as:AuthService, private router:Router) { }

  ngOnInit(): void {
  }

  login(loginform:NgForm)
  {
    this.as.login(loginform.value);
    if (this.as.isAuthenticated())
    {
    this.router.navigate(['todolist']);
    }
    else {
      alert("Invalid Credentials");
    }

  }

  

}

export interface LoginDetails {
  username:string;
  password:string;
} 