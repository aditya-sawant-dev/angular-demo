import { Injectable } from '@angular/core';
import { users } from '../data/data';
import { LoginDetails } from '../login/login.component';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor() { }

  login(login: LoginDetails) {
    let user1: LoginDetails;
    for (let user of users) {
      if (user.username === login.username && user.password === login.password) {
        this.addToken();
      }
    }

  }

  isAuthenticated():boolean {
    if (sessionStorage.getItem('token')) {
      return true;
    }
    else {
      return false;
    }
  }

  addToken() {
    sessionStorage.setItem('token', "todo-demo");
  }
  removeToken() {
    sessionStorage.removeItem('token');
  }
}
