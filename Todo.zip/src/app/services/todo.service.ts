import { Injectable } from '@angular/core';
import { todos } from '../data/data';
import { Todo } from '../main/main.component';

@Injectable({
  providedIn: 'root'
})
export class TodoService {

  //todosdata:Todo[];
  constructor() {
    //this.todosdata=todos
  }

  addTodo(todo: Todo) {

    todos.push(todo);

  }

  getTodos() {
    return todos;
  }

  remove(removetodo: Todo) {
    let index;
    for (let i: number = 0; i < todos.length; i++) {
      let todo = todos[i];
      if (todo.todo === removetodo.todo) {
        index = i;
        break;
      }
    }
    if (index === undefined) {
    }
    else {
      todos.splice(index, 1);
    }
  }
}
