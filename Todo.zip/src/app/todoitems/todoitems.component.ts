import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { todos } from '../data/data';
import { Todo } from '../main/main.component';

@Component({
  selector: 'app-todoitems',
  templateUrl: './todoitems.component.html',
  styleUrls: ['./todoitems.component.css']
})
export class TodoitemsComponent implements OnInit, OnChanges {

  @Input()
  todo:Todo;

  constructor() { 
    this.todo = {todo:'',isChecked:false};
  }
  ngOnChanges(changes: SimpleChanges): void 
  { console.log("===="); 
    console.log(todos);
    //todos.push(this.todo);
  }

  ngOnInit(): void {
  }

}
