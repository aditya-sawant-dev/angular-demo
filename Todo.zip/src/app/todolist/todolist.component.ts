import { Component, Input, OnInit } from '@angular/core';
import { todos } from '../data/data';
import { Todo } from '../main/main.component';
import { TodoService } from '../services/todo.service';

@Component({
  selector: 'app-todolist',
  templateUrl: './todolist.component.html',
  styleUrls: ['./todolist.component.css']
})
export class TodolistComponent implements OnInit {

  @Input()
  itemleft:number = 0;

  todolist:Todo[];
  constructor(private todoService:TodoService) {
    this.todolist=[{todo:'',isChecked:false}];
   }

  ngOnInit(): void {
    console.log(todos);
    this.todolist=this.todoService.getTodos();
    console.log(this.todolist);
  }

  addTodoToTheList(todo:Todo)
  {
    console.log("Adding todo : " +todo );
    console.log(this.todolist.length);
    //this.todolist.push(todo);
    this.todoService.addTodo(todo);
    this.todolist=this.todoService.getTodos();
    
    console.log(this.todolist.length);
    
  }

  remove(todo:Todo)
  {
    this.todoService.remove(todo);
    this.todolist=this.todoService.getTodos();
    this.itemleft=this.itemleft - 1;
  }

}
